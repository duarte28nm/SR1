import socket
import json


localIP     = "127.0.0.1"
localPort   = 20001
MAX_BYTES  = 65535
endereco = (localIP, localPort)
servidor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
servidor.bind ((localIP, localPort))
print ('listening at {}'. format(servidor.getsockname()))


import socket
import json

filme1= {"nome":"Megamente","ano":2010,"censura":"Livre","genero":"Animacao","diretor":"Tom McGrath","elenco":"Will Ferrell, Tina Fey, Jonah Hill, David Cross e Brad Pitt ","nota(imdb)":7.2}

filme2= {"nome":"Titanic","ano":1997,"censura":"14","genero":"Drama","diretor":"James Cameron","elenco":"Leonardo Dicaprio, Billy Zane, Kate Winslet, Frances Fisher, Kathy Bates, Gloria Stuart, Bill Paxton, Victor Garber ","nota(imdb)":8.1}

filme3= {"nome":"Vingadores: Guerra infinita","ano":2018,"censura":"12","genero":"Acao","diretor":"Anthony Russo, Joe Russo","elenco":"Josh Brolin,Chris Pratt, Tom Hiddleston, Chadwick Boseman, Elizabeth Olsen, Paul Bettany, Anthony Mackie, Stan Sebastian, Dave Bautista, Vin Diesel, Bradley Cooper, Robert Downey Jr., Pom Klementieff, Tom Holland, Chris Hemsworth, Chris Evans, Scarlett Johansson, Mark Ruffalo, Benedict Cumberbatch, Zoe Saldana","nota(imdb)":8.5}

filme4= {"nome":"O Quarto de Jack","ano":2016,"censura":"12","genero":"Drama","diretor":"Lenny Abrahamson","elenco":"Brie Larson ,Jacob Tremblay,Joan Allen,William H. Macy ,Sean Bridgers ,Megan Park ,Cas Anvar ,Amanda Brugel ,Joe Pingue ,Tom McCamus ,Wendy Crewson ","nota(imdb)":8.2}

filme5= {"nome":"Sing Quem Canta Seus Males Espanta","ano":2016,"censura":"Livre","genero":"Animacao","diretor":"Garth Jennings","elenco":"Matthew McConaughey,Reese Witherspoon,Seth MacFarlane,Scarlett Johansson,John C. Reilly,Taron Egerton,Tori Kelly,Jennifer Saunders,Garth Jennings,Peter Serafinowicz","nota(imdb)":7.1}

filme6= {"nome":"Questao de tempo","ano":2013,"censura":"12","genero":"Romance","diretor":"Richard Curtis","elenco":"Rachel McAdams, Bill Nighy, Domhnall Gleeson, Tom Hollander, Margot Robbie, Lindsay Duncan, Lee Asquith-Coe, Vanessa Kirby, Lisa Eichhorn, Lydia Wilson, Matthew C. Martino","nota(imdb)":7.8}

filme7= {"nome":"Como eu era antes de voce", "ano":2016,"censura":"12","genero":"Romance","diretor":"Thea Sharrock","elenco":"Emilia Clarke,Sam Claflin ,Jenna Coleman,Matthew Lewis,Charles Dance,Janet McTeer ,Brendan Coyle,Steve Peacocke ,Vanessa Kirby","nota(imdb)":7.4}

filme8= {"nome":"Juntos pelo Acaso", "ano":2010,"censura":"14","genero":"Romance","diretor":"Greg Berlanti","elenco":"Katherine Heigl, Josh Duhamel, Christina Hendricks, Josh Lucas, Jean Smart, Melissa McCarthy, Faizon Love, Majandra Delfino, Alexis Clagett, Hayes MacArthur, Johanna Jowett","nota(imdb)":6.5}

filme9= {"nome":"Meu Malvado Favorito 3", "ano":2017,"censura":"Livre","genero":"Animacao","diretor":"Kyle Balda, Pierre Coffin","elenco":"Nev Scharrel,Kristen Wiig,Steve Carell,Miranda Cosgrove,Jenny Slate","nota(imdb)":6.3}

filme10= {"nome":"Marley e Eu", "ano":2008,"censura":"12","genero":"Comedia","diretor":"David Frankel","elenco":"Haley Bennett , Owen Wilson, Alan Arkin, Jennifer Aniston, Nathan Gamble, Kathleen Turner, Eric Dane, Sarah Kelly ","nota(imdb)":7.1}
filmes = []

filmes.append(filme1)
filmes.append(filme2)
filmes.append(filme3)
filmes.append(filme4)
filmes.append(filme5)
filmes.append(filme6)
filmes.append(filme7)
filmes.append(filme8)
filmes.append(filme9)
filmes.append(filme10)

filmeArq = open("FilmesArq.json", "w")
json.dump(filmes,filmeArq)
filmeArq.close()

def mostraCatal():
    cont = 0
    listaFilmeAux = []
    for number in filmes:
        t = ("{}\nAno de lancamento: {}\nDiretor: {}\nElenco: {}\nGenero: {}\nCensura: {}\nNota:{}\n".format(filmes[cont]["nome"], filmes[cont]["ano"],filmes[cont]["diretor"],filmes[cont]["elenco"], filmes[cont]["genero"],filmes[cont]["censura"], filmes[cont]["nota(imdb)"]))
        listaFilmeAux.append(t)
        cont += 1
    return listaFilmeAux

def inserirFilme(listaAux):
    for numb in listaAux:
        print(numb)
    nome = listaAux[0]
    ano = listaAux[5]
    censura = listaAux[4]
    genero = listaAux[1]
    diretor = listaAux[2]
    elenco = listaAux[3]
    nota = listaAux[6]
    filmeArq = open("FilmesArq.json", "w")
    dicGenerico = {"nome":nome, "nota(imdb)": nota, "genero": genero, "ano":ano, "diretor":diretor, "censura": censura, "elenco":elenco}
    filmes.append(dicGenerico)
    json.dump(filmes,filmeArq)
    filmeArq.close()

def buscarFilme(listaAux):
    nome = listaAux[0]
    cont = 0
    print(filmes)
    result = ("Nao temos esse filme")
    for number in filmes:
        if nome == number["nome"]:
            result = ("{}\nAno de lancamento: {}\nDiretor: {}\nElenco: {}\nGenero: {}\nCensura: {}\nNota: {}\n".format(filmes[cont]["nome"], filmes[cont]["ano"],filmes[cont]["diretor"],filmes[cont]["elenco"], filmes[cont]["genero"],filmes[cont]["censura"], filmes[cont]["nota(imdb)"]))
            break
        cont += 1
    return result


def removerFilme(listaAux):
    nome = listaAux[0]
    cont = 0
    resul = ("Nao temos esse filme no catalogo")
    for number in filmes:
        if nome == number["nome"]:
            filmes.pop(cont)
            resul = ("Filmne removido")
            break
        cont += 1
    return resul

def mostGen(listaAux):
    genero = listaAux[0]
    cont = 0
    listaFilmeAux = []
    for number in filmes:
        if genero == number["genero"]:
            print(cont)
            t = ("{}\nAno de lancamento: {}\nDiretor: {}\nElenco: {}\nGenero: {}\nCensura: {}\nNota:{}\n".format(filmes[cont]["nome"], filmes[cont]["ano"], filmes[cont]["diretor"], filmes[cont]["elenco"],filmes[cont]["genero"], filmes[cont]["censura"], filmes[cont]["nota(imdb)"]))
            listaFilmeAux.append(t)
        cont += 1
    for n in listaFilmeAux:
        print(n)
    return listaFilmeAux



while True:
    #servidor.sendto(dado, address)
    while True:
        alt, endereco = servidor.recvfrom(MAX_BYTES)
        alt = str(alt.decode())
        if alt == "1":
            cont = 0
            listaAux = []
            while (cont < 7):
                if (cont <= 4):
                    valor, endereco = servidor.recvfrom(MAX_BYTES)
                    valor = str(valor.decode())
                    listaAux.append(valor)
                    cont += 1
                elif (cont== 5):
                    valor, endereco = servidor.recvfrom(MAX_BYTES)
                    valor = int(valor.decode())
                    listaAux.append(valor)
                    cont += 1
                elif (cont==6):
                    valor, endereco = servidor.recvfrom(MAX_BYTES)
                    valor = float(valor.decode())
                    listaAux.append(valor)
                    cont += 1
            inserirFilme(listaAux)
        elif alt == "2":
            listaAux = []
            nomeBusc, endereco = servidor.recvfrom(MAX_BYTES)
            nomeBusc = nomeBusc.decode()
            listaAux.append(nomeBusc)
            resulBusc = buscarFilme(listaAux)
            servidor.sendto(resulBusc.encode(), endereco)

        elif alt == "3":
            resulMostra = mostraCatal()
            resultadinho = json.dumps(resulMostra)
            servidor.sendto(resultadinho.encode(), endereco)

        elif alt == "4":
            listaAux = []
            nomeRemo, endereco = servidor.recvfrom(MAX_BYTES)
            nomeRemo = nomeRemo.decode()
            listaAux.append(nomeRemo)
            resulRemo = removerFilme(listaAux)
            servidor.sendto(resulRemo.encode(), endereco)

        elif alt == "5":
            listaAux = []
            nome, endereco = servidor.recvfrom(MAX_BYTES)
            nome = nome.decode()
            listaAux.append(nome)
            resulGen = mostGen(listaAux)
            resulGenA = json.dumps(resulGen)
            servidor.sendto(resulGenA.encode(), endereco)

        elif (alt=="0"):
            servidor.close()
            break