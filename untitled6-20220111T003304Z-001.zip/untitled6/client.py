import socket
import json


def menuPrincipal():
    print(" ___________________________________________________________ ")
    print("| Vamos lá, para mais uma grande aventura!!! tá preparado?! |")
    print("|                                                           |")
    print("|                       Tela inicial                        |")
    print("|       _____________________       _______________         |")
    print("|      |inserir um novo filme|     |buscar um filme|        |")
    print("|       ________________            _____________           |")
    print("|      |ver todos filmes|          |excluir filme|          |")
    print("|       _______________             ________________        |")
    print("|      |Pesquisar filme|           |SAIR            |       |")
    print("|                                  |Não sair agora, |       |")
    print("|                                  |fica mais!!!    |       |")
    print("|                                                           |")
    print(" ___________________________________________________________|")



vNome = ("Nome: ")
vAno = ("Ano: ")
vCensura=("Censura: ")
vGen = ("Genero: ")
vDir = ("Diretor: ")
vElenco = ("Elenco: ")
vNota = ("Nota(IMDB): ")



ClocalHost = "localhost"
ClocalPort = 20001
MAX_BYTES = 65535
servidor = (ClocalHost, ClocalPort)
conexao = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
    menuPrincipal()
    alt = str(input())
    conexao.sendto(alt.encode(), servidor)
    #dado, address = conexao.recvfrom(MAX_BYTES)
    if alt == "1":
        print(vNome)
        nome = str(input())
        conexao.sendto(nome.encode(), servidor)
        print(vGen)
        genero = str(input())
        conexao.sendto(genero.encode(), servidor)
        print(vDir)
        diret = str(input())
        conexao.sendto(diret.encode(), servidor)
        print(vElenco)
        elenco = str(input())
        conexao.sendto(elenco.encode(), servidor)
        print(vCensura)
        censura = str(input())
        conexao.sendto(censura.encode(), servidor)
        print(vAno)
        ano = str(input())
        conexao.sendto(ano.encode(), servidor)
        print(vNota)
        notaP = str(input())
        conexao.sendto(notaP.encode(), servidor)
        print("Filme adicionado!")
        input()

    elif alt == "2":
        print("Digite o Nome do filme que deseja buscar:")
        nomeBusc = str(input())
        conexao.sendto(nomeBusc.encode(), servidor)
        resultBusc, servidor = conexao.recvfrom(MAX_BYTES)
        resultBusc = str(resultBusc.decode())
        print(resultBusc)
        input()

    elif alt == "3":
        lista = []
        resultMostra, servidor = conexao.recvfrom(MAX_BYTES)
        lista = json.loads(resultMostra.decode())
        for num in lista:
            print(num)

    elif alt == "4":
        print("Digite o Nome do filme que deseja remover:")
        nomeRemo = str(input())
        conexao.sendto(nomeRemo.encode(), servidor)
        resultRemo, servidor = conexao.recvfrom(MAX_BYTES)
        resultRemo = str(resultRemo.decode())
        print(resultRemo)
        input()

    elif alt == "5":
        print("Digite o Genero que deseja pesquisar")
        nome = str(input())
        lista = []
        conexao.sendto(nome.encode(), servidor)
        resuGen, servidor = conexao.recvfrom(MAX_BYTES)
        lista = json.loads(resuGen.decode())
        for num in lista:
            print(num)
        input()

    elif alt == "0":
        conexao.close()
        break